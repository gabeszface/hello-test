package app.rechnungsfach;

import android.content.Context;
import android.net.Uri;

import org.json.JSONArray;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** Sicherung aller Belege samt Fotos in eine einzige ZIP-Datei. */
public final class Backup {

    private Backup() {
    }

    public static void export(Context c, Uri uri) throws Exception {
        List<Receipt> all = Db.get(c).all();
        JSONArray arr = new JSONArray();
        for (Receipt r : all) arr.put(r.toJson());

        OutputStream os = c.getContentResolver().openOutputStream(uri);
        if (os == null) throw new IOException("Datei kann nicht geschrieben werden");
        File photos = ImageUtil.photosDir(c);
        try (ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(os))) {
            zip.putNextEntry(new ZipEntry("data.json"));
            zip.write(arr.toString(2).getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
            for (Receipt r : all) {
                if (r.photo == null) continue;
                File f = new File(photos, r.photo);
                if (!f.exists()) continue;
                zip.putNextEntry(new ZipEntry("photos/" + r.photo));
                try (InputStream in = new FileInputStream(f)) {
                    copy(in, zip);
                }
                zip.closeEntry();
            }
        }
    }

    public static int restore(Context c, Uri uri) throws Exception {
        File tmp = new File(c.getCacheDir(), "restore");
        deleteDir(tmp);
        tmp.mkdirs();

        String json = null;
        InputStream is = c.getContentResolver().openInputStream(uri);
        if (is == null) throw new IOException("Datei kann nicht gelesen werden");
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(is))) {
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                String name = e.getName();
                if (name.equals("data.json")) {
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    copy(zin, bo);
                    json = new String(bo.toByteArray(), StandardCharsets.UTF_8);
                } else if (name.startsWith("photos/")) {
                    String fn = new File(name).getName();
                    if (fn.isEmpty()) continue;
                    try (FileOutputStream out = new FileOutputStream(new File(tmp, fn))) {
                        copy(zin, out);
                    }
                }
            }
        }
        if (json == null) {
            deleteDir(tmp);
            throw new IOException("Keine gültige Sicherung (data.json fehlt)");
        }

        JSONArray arr = new JSONArray(json);
        List<Receipt> list = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) list.add(Receipt.fromJson(arr.getJSONObject(i)));

        File photos = ImageUtil.photosDir(c);
        File[] old = photos.listFiles();
        if (old != null) for (File f : old) f.delete();
        File[] fresh = tmp.listFiles();
        if (fresh != null) {
            for (File f : fresh) {
                File dest = new File(photos, f.getName());
                if (!f.renameTo(dest)) {
                    try (InputStream in = new FileInputStream(f);
                         OutputStream out = new FileOutputStream(dest)) {
                        copy(in, out);
                    }
                }
            }
        }
        for (Receipt r : list) {
            if (r.photo != null && !new File(photos, r.photo).exists()) r.photo = null;
        }
        Db.get(c).replaceAll(list);
        deleteDir(tmp);
        return list.size();
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }

    private static void deleteDir(File d) {
        File[] files = d.listFiles();
        if (files != null) for (File f : files) f.delete();
        d.delete();
    }
}
