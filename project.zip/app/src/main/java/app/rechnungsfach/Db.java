package app.rechnungsfach;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class Db extends SQLiteOpenHelper {

    private static Db instance;

    public static synchronized Db get(Context c) {
        if (instance == null) instance = new Db(c.getApplicationContext());
        return instance;
    }

    private Db(Context c) {
        super(c, "receipts.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE receipts (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "title TEXT, shop TEXT, price TEXT, note TEXT, photo TEXT, " +
                "category INTEGER, warranty INTEGER, purchase INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        // Noch keine Migrationen.
    }

    private ContentValues values(Receipt r) {
        ContentValues v = new ContentValues();
        v.put("title", r.title);
        v.put("shop", r.shop);
        v.put("price", r.price);
        v.put("note", r.note);
        v.put("photo", r.photo);
        v.put("category", r.category);
        v.put("warranty", r.warrantyMonths);
        v.put("purchase", r.purchaseDate);
        return v;
    }

    private Receipt read(Cursor c) {
        Receipt r = new Receipt();
        r.id = c.getLong(0);
        r.title = nz(c.getString(1));
        r.shop = nz(c.getString(2));
        r.price = nz(c.getString(3));
        r.note = nz(c.getString(4));
        r.photo = c.isNull(5) ? null : c.getString(5);
        r.category = c.getInt(6);
        r.warrantyMonths = c.getInt(7);
        r.purchaseDate = c.getLong(8);
        return r;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private static final String COLS =
            "id, title, shop, price, note, photo, category, warranty, purchase";

    public synchronized long save(Receipt r) {
        SQLiteDatabase db = getWritableDatabase();
        if (r.id < 0) {
            r.id = db.insert("receipts", null, values(r));
        } else {
            db.update("receipts", values(r), "id=?", new String[]{String.valueOf(r.id)});
        }
        return r.id;
    }

    public synchronized Receipt get(long id) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT " + COLS + " FROM receipts WHERE id=?",
                new String[]{String.valueOf(id)})) {
            return c.moveToFirst() ? read(c) : null;
        }
    }

    public synchronized List<Receipt> all() {
        List<Receipt> list = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT " + COLS + " FROM receipts ORDER BY purchase DESC, id DESC", null)) {
            while (c.moveToNext()) list.add(read(c));
        }
        return list;
    }

    public synchronized void delete(long id) {
        getWritableDatabase().delete("receipts", "id=?", new String[]{String.valueOf(id)});
    }

    public synchronized void replaceAll(List<Receipt> list) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("receipts", null, null);
            for (Receipt r : list) {
                r.id = db.insert("receipts", null, values(r));
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }
}
