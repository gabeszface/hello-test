package app.rechnungsfach;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EditActivity extends Activity {

    private static final int REQ_CAMERA = 10;
    private static final int REQ_GALLERY = 11;
    private static final int[] WARRANTY = {0, 6, 12, 24, 36, 60};

    private final ExecutorService exec = Executors.newSingleThreadExecutor();

    private Receipt r;
    private String originalPhoto;
    private String photo;
    private String pendingCamera;
    private boolean saved;

    private EditText title, shop, price, note;
    private Button dateBtn, removeBtn, saveBtn;
    private Spinner category, warranty;
    private ImageView image;
    private DateFormat df;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_edit);
        df = DateFormat.getDateInstance(DateFormat.MEDIUM);

        title = findViewById(R.id.title);
        shop = findViewById(R.id.shop);
        price = findViewById(R.id.price);
        note = findViewById(R.id.note);
        dateBtn = findViewById(R.id.date);
        removeBtn = findViewById(R.id.remove);
        saveBtn = findViewById(R.id.save);
        category = findViewById(R.id.category);
        warranty = findViewById(R.id.warranty);
        image = findViewById(R.id.image);
        Button deleteBtn = findViewById(R.id.delete);

        ArrayAdapter<CharSequence> ca = ArrayAdapter.createFromResource(this,
                R.array.categories, android.R.layout.simple_spinner_item);
        ca.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        category.setAdapter(ca);
        ArrayAdapter<CharSequence> wa = ArrayAdapter.createFromResource(this,
                R.array.warranty_labels, android.R.layout.simple_spinner_item);
        wa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        warranty.setAdapter(wa);

        long id = getIntent().getLongExtra("id", -1);
        r = id >= 0 ? Db.get(this).get(id) : null;
        if (r == null) {
            r = new Receipt();
            r.purchaseDate = today();
            setTitle(R.string.new_receipt);
        } else {
            setTitle(R.string.edit_receipt);
            deleteBtn.setVisibility(View.VISIBLE);
        }
        originalPhoto = r.photo;
        photo = r.photo;

        if (s == null) {
            title.setText(r.title);
            shop.setText(r.shop);
            price.setText(r.price);
            note.setText(r.note);
            category.setSelection(Math.max(0, Math.min(r.category, ca.getCount() - 1)));
            int w = 3;
            for (int i = 0; i < WARRANTY.length; i++) if (WARRANTY[i] == r.warrantyMonths) w = i;
            warranty.setSelection(w);
        } else {
            r.purchaseDate = s.getLong("date", r.purchaseDate);
            photo = s.getString("photo");
            pendingCamera = s.getString("pending");
        }

        updateDate();
        updatePhoto();

        dateBtn.setOnClickListener(v -> pickDate());
        findViewById(R.id.take).setOnClickListener(v -> takePhoto());
        findViewById(R.id.pick).setOnClickListener(v -> pickPhoto());
        removeBtn.setOnClickListener(v -> setPhoto(null));
        image.setOnClickListener(v -> {
            if (photo != null) {
                Intent i = new Intent(this, PhotoActivity.class);
                i.putExtra("photo", photo);
                startActivity(i);
            }
        });
        saveBtn.setOnClickListener(v -> save());
        deleteBtn.setOnClickListener(v -> confirmDelete());
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putLong("date", r.purchaseDate);
        out.putString("photo", photo);
        out.putString("pending", pendingCamera);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        exec.shutdown();
        // Neu aufgenommenes, aber nicht gespeichertes Foto aufräumen.
        if (isFinishing() && !saved && photo != null && !photo.equals(originalPhoto)) {
            file(photo).delete();
        }
    }

    private static long today() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private File file(String name) {
        return new File(ImageUtil.photosDir(this), name);
    }

    private static String newName() {
        return "IMG_" + System.currentTimeMillis() + ".jpg";
    }

    // ---------- Datum ----------

    private void updateDate() {
        dateBtn.setText(df.format(new Date(r.purchaseDate)));
    }

    private void pickDate() {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(r.purchaseDate);
        new DatePickerDialog(this, (v, y, m, d) -> {
            Calendar n = Calendar.getInstance();
            n.clear();
            n.set(y, m, d);
            r.purchaseDate = n.getTimeInMillis();
            updateDate();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    // ---------- Foto ----------

    private void setPhoto(String newName) {
        if (photo != null && !photo.equals(originalPhoto) && !photo.equals(newName)) {
            file(photo).delete();
        }
        photo = newName;
        updatePhoto();
    }

    private void updatePhoto() {
        if (photo == null) {
            image.setScaleType(ImageView.ScaleType.CENTER);
            image.setImageResource(android.R.drawable.ic_menu_camera);
            removeBtn.setVisibility(View.GONE);
            return;
        }
        removeBtn.setVisibility(View.VISIBLE);
        final String p = photo;
        exec.execute(() -> {
            try {
                Bitmap b = ImageUtil.decode(() -> new FileInputStream(file(p)), 1200);
                runOnUiThread(() -> {
                    if (p.equals(photo)) {
                        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                        image.setImageBitmap(b);
                    }
                });
            } catch (Exception ignored) {
            }
        });
    }

    private void takePhoto() {
        String name = newName();
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file(name));
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        i.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        pendingCamera = name;
        try {
            startActivityForResult(i, REQ_CAMERA);
        } catch (ActivityNotFoundException e) {
            pendingCamera = null;
            Toast.makeText(this, R.string.no_camera, Toast.LENGTH_LONG).show();
        }
    }

    private void pickPhoto() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(i, getString(R.string.pick_photo)), REQ_GALLERY);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CAMERA) {
            String name = pendingCamera;
            pendingCamera = null;
            if (name == null) return;
            final File f = file(name);
            if (res == RESULT_OK && f.exists() && f.length() > 0) {
                processImage(() -> new FileInputStream(f), name);
            } else {
                f.delete();
            }
        } else if (req == REQ_GALLERY) {
            if (res != RESULT_OK || data == null || data.getData() == null) return;
            final Uri u = data.getData();
            processImage(() -> {
                InputStream in = getContentResolver().openInputStream(u);
                if (in == null) throw new IOException("Bild nicht lesbar");
                return in;
            }, newName());
        }
    }

    /** Verkleinert das Bild im Hintergrund und übernimmt es dann. */
    private void processImage(ImageUtil.StreamSource src, String name) {
        saveBtn.setEnabled(false);
        exec.execute(() -> {
            try {
                ImageUtil.importImage(src, file(name));
                runOnUiThread(() -> {
                    saveBtn.setEnabled(true);
                    setPhoto(name);
                });
            } catch (Exception e) {
                file(name).delete();
                runOnUiThread(() -> {
                    saveBtn.setEnabled(true);
                    Toast.makeText(this, getString(R.string.error, String.valueOf(e.getMessage())),
                            Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    // ---------- Speichern / Löschen ----------

    private void save() {
        String t = title.getText().toString().trim();
        if (t.isEmpty()) {
            title.setError(getString(R.string.title_required));
            title.requestFocus();
            return;
        }
        r.title = t;
        r.shop = shop.getText().toString().trim();
        r.price = price.getText().toString().trim();
        r.note = note.getText().toString().trim();
        r.category = category.getSelectedItemPosition();
        r.warrantyMonths = WARRANTY[warranty.getSelectedItemPosition()];
        r.photo = photo;
        Db.get(this).save(r);
        if (originalPhoto != null && !originalPhoto.equals(photo)) file(originalPhoto).delete();
        saved = true;
        finish();
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setMessage(R.string.delete_confirm)
                .setPositiveButton(R.string.delete, (d, w) -> {
                    Db.get(this).delete(r.id);
                    if (photo != null) file(photo).delete();
                    if (originalPhoto != null) file(originalPhoto).delete();
                    saved = true;
                    finish();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
}
