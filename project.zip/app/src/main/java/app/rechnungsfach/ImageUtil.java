package app.rechnungsfach;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public final class ImageUtil {

    public interface StreamSource {
        InputStream open() throws IOException;
    }

    private ImageUtil() {
    }

    public static File photosDir(Context c) {
        File d = new File(c.getFilesDir(), "photos");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    /** Lädt ein Bild verkleinert (längste Seite max. maxSize) und richtig gedreht. */
    public static Bitmap decode(StreamSource src, int maxSize) throws IOException {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = src.open()) {
            BitmapFactory.decodeStream(in, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IOException("Kein Bild");

        int sample = 1;
        while (bounds.outWidth / (sample * 2) >= maxSize || bounds.outHeight / (sample * 2) >= maxSize) {
            sample *= 2;
        }
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        Bitmap b;
        try (InputStream in = src.open()) {
            b = BitmapFactory.decodeStream(in, null, opts);
        }
        if (b == null) throw new IOException("Bild konnte nicht gelesen werden");

        int rotation = 0;
        try (InputStream in = src.open()) {
            ExifInterface exif = new ExifInterface(in);
            int o = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            if (o == ExifInterface.ORIENTATION_ROTATE_90) rotation = 90;
            else if (o == ExifInterface.ORIENTATION_ROTATE_180) rotation = 180;
            else if (o == ExifInterface.ORIENTATION_ROTATE_270) rotation = 270;
        } catch (Exception ignored) {
        }

        float scale = Math.min(1f, (float) maxSize / Math.max(b.getWidth(), b.getHeight()));
        if (rotation != 0 || scale < 1f) {
            Matrix m = new Matrix();
            m.postScale(scale, scale);
            m.postRotate(rotation);
            Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            if (r != b) b.recycle();
            b = r;
        }
        return b;
    }

    /** Liest ein Bild, verkleinert es auf max. 2000 px und speichert es als JPEG. */
    public static void importImage(StreamSource src, File dest) throws IOException {
        Bitmap b = decode(src, 2000);
        try (FileOutputStream out = new FileOutputStream(dest)) {
            b.compress(Bitmap.CompressFormat.JPEG, 85, out);
        } finally {
            b.recycle();
        }
    }
}
