package app.rechnungsfach;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final int REQ_BACKUP = 1;
    private static final int REQ_RESTORE = 2;
    private static final int MENU_BACKUP = 1;
    private static final int MENU_RESTORE = 2;
    private static final long DAY = 24L * 60 * 60 * 1000;

    private final List<Receipt> all = new ArrayList<>();
    private final List<Receipt> shown = new ArrayList<>();
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final LruCache<String, Bitmap> thumbs = new LruCache<>(80);

    private EditText search;
    private Spinner filter;
    private TextView empty;
    private ReceiptAdapter adapter;
    private DateFormat df;
    private String[] categories;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        df = DateFormat.getDateInstance(DateFormat.MEDIUM);
        categories = getResources().getStringArray(R.array.categories);

        search = findViewById(R.id.search);
        filter = findViewById(R.id.filter);
        empty = findViewById(R.id.empty);
        ListView list = findViewById(R.id.list);

        List<String> f = new ArrayList<>();
        f.add(getString(R.string.all_categories));
        f.addAll(Arrays.asList(categories));
        ArrayAdapter<String> fa = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, f);
        fa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        filter.setAdapter(fa);
        filter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                applyFilter();
            }

            @Override
            public void onNothingSelected(AdapterView<?> p) {
            }
        });

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                applyFilter();
            }
        });

        adapter = new ReceiptAdapter();
        list.setAdapter(adapter);
        list.setEmptyView(empty);
        list.setOnItemClickListener((p, v, pos, id) -> open(shown.get(pos).id));
        findViewById(R.id.add).setOnClickListener(v -> open(-1));
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        exec.shutdown();
    }

    private void reload() {
        all.clear();
        all.addAll(Db.get(this).all());
        applyFilter();
    }

    private void applyFilter() {
        if (adapter == null) return;
        String q = search.getText().toString().trim().toLowerCase(Locale.ROOT);
        int cat = filter.getSelectedItemPosition() - 1;
        shown.clear();
        for (Receipt r : all) {
            if (cat >= 0 && r.category != cat) continue;
            if (!q.isEmpty()) {
                String hay = (r.title + " " + r.shop + " " + r.note + " " + r.price).toLowerCase(Locale.ROOT);
                if (!hay.contains(q)) continue;
            }
            shown.add(r);
        }
        empty.setText(all.isEmpty() ? R.string.empty_list : R.string.no_results);
        adapter.notifyDataSetChanged();
    }

    private void open(long id) {
        Intent i = new Intent(this, EditActivity.class);
        i.putExtra("id", id);
        startActivity(i);
    }

    // ---------- Menü: Sichern / Wiederherstellen ----------

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, MENU_BACKUP, 0, R.string.backup);
        menu.add(0, MENU_RESTORE, 1, R.string.restore);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == MENU_BACKUP) {
            String date = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(new Date());
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/zip");
            i.putExtra(Intent.EXTRA_TITLE, "Rechnungsfach-Backup-" + date + ".zip");
            startActivityForResult(i, REQ_BACKUP);
            return true;
        }
        if (item.getItemId() == MENU_RESTORE) {
            new AlertDialog.Builder(this)
                    .setMessage(R.string.restore_confirm)
                    .setPositiveButton(R.string.proceed, (d, w) -> {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("*/*");
                        startActivityForResult(i, REQ_RESTORE);
                    })
                    .setNegativeButton(R.string.cancel, null)
                    .show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        if (req == REQ_BACKUP) {
            exec.execute(() -> {
                try {
                    Backup.export(this, uri);
                    runOnUiThread(() -> Toast.makeText(this, R.string.backup_ok, Toast.LENGTH_LONG).show());
                } catch (Exception e) {
                    showError(e);
                }
            });
        } else if (req == REQ_RESTORE) {
            exec.execute(() -> {
                try {
                    int n = Backup.restore(this, uri);
                    runOnUiThread(() -> {
                        thumbs.evictAll();
                        reload();
                        Toast.makeText(this, getString(R.string.restore_ok, n), Toast.LENGTH_LONG).show();
                    });
                } catch (Exception e) {
                    showError(e);
                }
            });
        }
    }

    private void showError(Exception e) {
        runOnUiThread(() -> Toast.makeText(this,
                getString(R.string.error, String.valueOf(e.getMessage())), Toast.LENGTH_LONG).show());
    }

    // ---------- Liste ----------

    private class ReceiptAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return shown.size();
        }

        @Override
        public Object getItem(int pos) {
            return shown.get(pos);
        }

        @Override
        public long getItemId(int pos) {
            return shown.get(pos).id;
        }

        @Override
        public View getView(int pos, View view, ViewGroup parent) {
            if (view == null) {
                view = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_receipt, parent, false);
            }
            Receipt r = shown.get(pos);
            TextView title = view.findViewById(R.id.title);
            TextView subtitle = view.findViewById(R.id.subtitle);
            TextView warranty = view.findViewById(R.id.warranty);
            final ImageView img = view.findViewById(R.id.thumb);

            title.setText(r.title);

            StringBuilder sb = new StringBuilder();
            if (!r.shop.isEmpty()) sb.append(r.shop).append(" · ");
            sb.append(df.format(new Date(r.purchaseDate)));
            if (!r.price.isEmpty()) sb.append(" · ").append(r.price).append(" €");
            if (r.category >= 0 && r.category < categories.length) {
                sb.append(" · ").append(categories[r.category]);
            }
            subtitle.setText(sb.toString());

            long end = r.warrantyEnd();
            long now = System.currentTimeMillis();
            if (end < 0) {
                warranty.setText(R.string.no_warranty);
                warranty.setTextColor(Color.parseColor("#888888"));
            } else if (end < now) {
                warranty.setText(getString(R.string.warranty_expired, df.format(new Date(end))));
                warranty.setTextColor(Color.parseColor("#C62828"));
            } else if (end - now < 90 * DAY) {
                warranty.setText(getString(R.string.warranty_until, df.format(new Date(end))));
                warranty.setTextColor(Color.parseColor("#E65100"));
            } else {
                warranty.setText(getString(R.string.warranty_until, df.format(new Date(end))));
                warranty.setTextColor(Color.parseColor("#2E7D32"));
            }

            final String name = r.photo;
            img.setTag(name);
            if (name == null) {
                img.setScaleType(ImageView.ScaleType.CENTER);
                img.setImageResource(android.R.drawable.ic_menu_gallery);
            } else {
                img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                Bitmap cached = thumbs.get(name);
                if (cached != null) {
                    img.setImageBitmap(cached);
                } else {
                    img.setImageDrawable(null);
                    exec.execute(() -> {
                        try {
                            File f = new File(ImageUtil.photosDir(MainActivity.this), name);
                            Bitmap b = ImageUtil.decode(() -> new FileInputStream(f), 200);
                            thumbs.put(name, b);
                            runOnUiThread(() -> {
                                if (name.equals(img.getTag())) img.setImageBitmap(b);
                            });
                        } catch (Exception ignored) {
                        }
                    });
                }
            }
            return view;
        }
    }
}
