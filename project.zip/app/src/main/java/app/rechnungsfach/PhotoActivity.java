package app.rechnungsfach;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageView;

import java.io.File;
import java.io.FileInputStream;

/** Zeigt das Foto eines Belegs im Vollbild. Antippen schließt es. */
public class PhotoActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ImageView iv = new ImageView(this);
        iv.setBackgroundColor(Color.BLACK);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setOnClickListener(v -> finish());
        setContentView(iv);

        String name = getIntent().getStringExtra("photo");
        if (name == null) return;
        File f = new File(ImageUtil.photosDir(this), name);
        new Thread(() -> {
            try {
                Bitmap b = ImageUtil.decode(() -> new FileInputStream(f), 2000);
                runOnUiThread(() -> iv.setImageBitmap(b));
            } catch (Exception ignored) {
            }
        }).start();
    }
}
