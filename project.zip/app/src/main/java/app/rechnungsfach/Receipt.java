package app.rechnungsfach;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;

public class Receipt {
    public long id = -1;
    public String title = "";
    public String shop = "";
    public String price = "";
    public String note = "";
    public String photo = null;
    public int category = 0;
    public int warrantyMonths = 24;
    public long purchaseDate = 0;

    /** Garantie-Ende in Millisekunden, oder -1 wenn keine Garantie. */
    public long warrantyEnd() {
        if (warrantyMonths <= 0) return -1;
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(purchaseDate);
        c.add(Calendar.MONTH, warrantyMonths);
        return c.getTimeInMillis();
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("title", title);
        o.put("shop", shop);
        o.put("price", price);
        o.put("note", note);
        if (photo != null) o.put("photo", photo);
        o.put("category", category);
        o.put("warranty", warrantyMonths);
        o.put("purchase", purchaseDate);
        return o;
    }

    public static Receipt fromJson(JSONObject o) {
        Receipt r = new Receipt();
        r.title = o.optString("title", "");
        r.shop = o.optString("shop", "");
        r.price = o.optString("price", "");
        r.note = o.optString("note", "");
        r.photo = (o.has("photo") && !o.isNull("photo")) ? o.optString("photo", null) : null;
        r.category = o.optInt("category", 0);
        r.warrantyMonths = o.optInt("warranty", 24);
        r.purchaseDate = o.optLong("purchase", System.currentTimeMillis());
        return r;
    }
}
