package com.example.hello;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(48, 48, 48, 48);

        final TextView title = new TextView(this);
        title.setText("Működik! 🎉");
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);

        final TextView counter = new TextView(this);
        counter.setText("Koppintások: 0");
        counter.setTextSize(20);
        counter.setGravity(Gravity.CENTER);
        counter.setPadding(0, 32, 0, 32);

        Button button = new Button(this);
        button.setText("Koppints rám");
        button.setOnClickListener(v -> {
            count++;
            counter.setText("Koppintások: " + count);
        });

        root.addView(title);
        root.addView(counter);
        root.addView(button);
        setContentView(root);
    }
}
